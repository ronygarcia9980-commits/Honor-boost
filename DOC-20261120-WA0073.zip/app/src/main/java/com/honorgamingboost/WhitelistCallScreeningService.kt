package com.honorgamingboost

import android.telecom.Call
import android.telecom.CallScreeningService

/**
 * Local screening only. When the master switch is OFF, all calls pass.
 * When ON, only numbers individually enabled in the app are allowed.
 */
class WhitelistCallScreeningService : CallScreeningService() {
    override fun onScreenCall(details: Call.Details) {
        if (details.callDirection != Call.Details.DIRECTION_INCOMING) {
            respondToCall(details, CallResponse.Builder().setDisallowCall(false).build())
            return
        }
        val prefs = getSharedPreferences("hgb_settings", MODE_PRIVATE)
        val enabled = prefs.getBoolean("call_filter_enabled", false)
        val number = details.handle?.schemeSpecificPart.orEmpty()
        val allowed = prefs.getStringSet("allowed_numbers", emptySet())
            ?.contains(normalizeNumber(number)) == true
        val block = enabled && !allowed
        val response = CallResponse.Builder()
            .setDisallowCall(block)
            .setRejectCall(block)
            .setSkipCallLog(false)
            .setSkipNotification(false)
            .build()
        respondToCall(details, response)
    }
}

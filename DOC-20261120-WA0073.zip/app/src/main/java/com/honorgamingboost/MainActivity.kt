package com.honorgamingboost

import android.Manifest
import android.content.ContentUris
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.provider.Settings
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import android.app.role.RoleManager
import android.os.Build

private const val PREFS = "hgb_settings"
private const val KEY_MASTER = "call_filter_enabled"
private const val KEY_ALLOWED = "allowed_numbers"

data class PhoneContact(val name: String, val number: String)

class MainActivity : ComponentActivity() {
    private val contactPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) setContent { AppScreen() }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AppScreen() }
    }

    @Composable
    private fun AppScreen() {
        val prefs = remember { getSharedPreferences(PREFS, Context.MODE_PRIVATE) }
        var master by remember { mutableStateOf(prefs.getBoolean(KEY_MASTER, false)) }
        var allowed by remember { mutableStateOf(prefs.getStringSet(KEY_ALLOWED, emptySet())!!.toSet()) }
        var contacts by remember { mutableStateOf(emptyList<PhoneContact>()) }
        var hasPermission by remember {
            mutableStateOf(ContextCompat.checkSelfPermission(this, Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED)
        }
        var tab by remember { mutableStateOf(0) }
        var query by remember { mutableStateOf("") }

        fun saveAllowed(next: Set<String>) {
            allowed = next
            prefs.edit().putStringSet(KEY_ALLOWED, next.toSet()).apply()
        }
        fun loadContacts() {
            if (!hasPermission) return
            val found = mutableListOf<PhoneContact>()
            val uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI
            contentResolver.query(uri, arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ), null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")?.use { c ->
                val ni = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME)
                val pi = c.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER)
                while (c.moveToNext()) {
                    val name = c.getString(ni) ?: "Sin nombre"
                    val number = c.getString(pi) ?: continue
                    if (number.isNotBlank()) found.add(PhoneContact(name, number))
                }
            }
            contacts = found.distinctBy { normalizeNumber(it.number) }
        }
        LaunchedEffect(hasPermission) { loadContacts() }

        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = androidx.compose.ui.graphics.Color(0xFF71E0B3),
                secondary = androidx.compose.ui.graphics.Color(0xFF8DBBFF),
                background = androidx.compose.ui.graphics.Color(0xFF0D1117),
                surface = androidx.compose.ui.graphics.Color(0xFF161D27)
            )
        ) {
            Scaffold(
                containerColor = MaterialTheme.colorScheme.background,
                bottomBar = {
                    NavigationBar(containerColor = MaterialTheme.colorScheme.surface) {
                        NavigationBarItem(selected = tab == 0, onClick = { tab = 0 }, icon = { Text("⚡") }, label = { Text("Inicio") })
                        NavigationBarItem(selected = tab == 1, onClick = { tab = 1 }, icon = { Text("☎") }, label = { Text("Llamadas") })
                        NavigationBarItem(selected = tab == 2, onClick = { tab = 2 }, icon = { Text("🛡") }, label = { Text("Seguridad") })
                        NavigationBarItem(selected = tab == 3, onClick = { tab = 3 }, icon = { Text("▣") }, label = { Text("Multi-app") })
                    }
                }
            ) { pad ->
                when (tab) {
                    0 -> LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("HONOR GAMING BOOST", style = MaterialTheme.typography.headlineSmall)
                            Text("ULTIMATE EDITION · MODO LIGERO", color = MaterialTheme.colorScheme.secondary)
                        }
                        item { ModuleCard("Gaming Boost", "Perfiles previstos: Mobile Legends, Brawl Stars y Clash Royale. Sin servicios permanentes ni animaciones pesadas.") }
                        item { ModuleCard("Monitor del teléfono", "Esta versión no mantiene sensores consultándose en segundo plano. La lectura de temperatura y batería queda pendiente.") }
                        item { ModuleCard("Ahorro de RAM", "Diseño ligero: sin procesos de limpieza continua, sin servicios residentes y sin cerrar aplicaciones a la fuerza.") }
                        item { ModuleCard("Filtro de llamadas", if (master) "Protección activada" else "Protección desactivada") }
                    }
                    1 -> LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item {
                            Text("Llamadas permitidas", style = MaterialTheme.typography.headlineSmall)
                            Text("Activa solo los contactos que sí pueden llamarte. No se borra ni modifica ningún contacto.")
                        }
                        item {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text("Bloqueo general", style = MaterialTheme.typography.titleMedium)
                                            Text(if (master) "Activo: solo números autorizados" else "Apagado: llamadas sin filtrar", style = MaterialTheme.typography.bodySmall)
                                        }
                                        Switch(checked = master, onCheckedChange = {
                                            master = it
                                            prefs.edit().putBoolean(KEY_MASTER, it).apply()
                                        })
                                    }
                                    Text("El botón de emergencia es este mismo interruptor: apágalo para pausar el bloqueo.")
                                    Button(onClick = { requestCallRole() }, modifier = Modifier.fillMaxWidth()) {
                                        Text("Configurar permiso de filtrado de llamadas")
                                    }
                                }
                            }
                        }
                        item {
                            OutlinedTextField(value = query, onValueChange = { query = it }, label = { Text("Buscar contacto") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                        }
                        if (!hasPermission) {
                            item {
                                Button(onClick = { contactPermission.launch(Manifest.permission.READ_CONTACTS) }) {
                                    Text("Permitir acceso a contactos")
                                }
                            }
                        } else {
                            items(contacts.filter { it.name.contains(query, true) || it.number.contains(query, true) }, key = { normalizeNumber(it.number) }) { contact ->
                                val key = normalizeNumber(contact.number)
                                Card(shape = RoundedCornerShape(14.dp)) {
                                    Row(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(contact.name, style = MaterialTheme.typography.titleSmall)
                                            Text(contact.number, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                                        }
                                        Switch(checked = allowed.contains(key), onCheckedChange = { checked ->
                                            saveAllowed(if (checked) allowed + key else allowed - key)
                                        })
                                    }
                                }
                            }
                        }
                    }
                    2 -> LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Seguridad", style = MaterialTheme.typography.headlineSmall) }
                        item { ModuleCard("Revisión de permisos", "Pendiente de implementar. Esta versión no afirma detectar todos los virus ni escanear los datos privados de otras aplicaciones.") }
                        item { Button(onClick = { runCatching { startActivity(Intent(Settings.ACTION_SECURITY_SETTINGS)) } }) { Text("Abrir seguridad de Android") } }
                        item { Button(onClick = { runCatching { startActivity(Intent("com.google.android.gms.security.SETTINGS")) } }) { Text("Abrir protección de Google (si está disponible)") } }
                        item { ModuleCard("Anti-spam SMS", "Pendiente. Para filtrar SMS completamente se necesita implementar una aplicación SMS y solicitar el rol predeterminado; no se activa sin tu permiso.") }
                    }
                    else -> LazyColumn(Modifier.fillMaxSize().padding(pad).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        item { Text("Multi-aplicación", style = MaterialTheme.typography.headlineSmall) }
                        item { ModuleCard("Ventanas flotantes", "Acceso a la función del sistema HONOR. La aplicación no reemplaza Game Booster ni fuerza ventanas en apps incompatibles.") }
                        item { Button(onClick = { runCatching { startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))) } }) { Text("Abrir ajustes de ventanas superpuestas") } }
                        item { Button(onClick = { runCatching { startActivity(Intent(Settings.ACTION_DISPLAY_SETTINGS)) } }) { Text("Abrir ajustes de pantalla") } }
                    }
                }
            }
        }
    }

    @Composable
    private fun ModuleCard(title: String, body: String) {
        Card(shape = RoundedCornerShape(18.dp)) {
            Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium)
                Text(body, style = MaterialTheme.typography.bodySmall)
            }
        }
    }

    private fun requestCallRole() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = getSystemService(RoleManager::class.java)
            if (rm.isRoleAvailable(RoleManager.ROLE_CALL_SCREENING)) {
                startActivity(rm.createRequestRoleIntent(RoleManager.ROLE_CALL_SCREENING))
            }
        }
    }
}

fun normalizeNumber(number: String): String = number.filter { it.isDigit() }.takeLast(10)

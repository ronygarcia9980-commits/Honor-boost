# HONOR GAMING BOOST — ULTIMATE EDITION 0.2 (fuente)

**Dispositivo objetivo:** HONOR X8b LLY-LX3 / MagicOS 8.
**Estado:** proyecto fuente ampliado; todavía NO es un APK compilado ni probado en el teléfono.

## Cambios incluidos en 0.2
- Interfaz oscura sencilla con navegación por módulos y listas perezosas (LazyColumn).
- Diseño deliberadamente ligero: sin animaciones decorativas, sin sondeo continuo de sensores, sin servicios de limpieza residentes.
- Lista de contactos leída localmente y con interruptor individual para autorizar/desautorizar cada número.
- Interruptor general de filtrado de llamadas; apagado = todas las llamadas pasan. Encendido = solo números habilitados individualmente pasan.
- El interruptor general sirve también como pausa/emergencia.
- La configuración de contactos se guarda localmente en preferencias privadas.
- No se modifica ni elimina ningún contacto. No se añade copia de seguridad.
- Accesos a ajustes del sistema para seguridad, pantalla y ventanas superpuestas.

## Importante
- Para que el filtro funcione hay que conceder permiso de contactos y elegir esta app como app de filtrado de llamadas del sistema (rol Call Screening).
- Antes de usarlo a diario, probar con otro teléfono. La normalización de números usa los últimos 10 dígitos; validar con operadores/números internacionales de Perú y doble SIM.
- SMS anti-spam todavía NO implementado. Un filtro SMS completo requiere desarrollar una app SMS predeterminada y solicitar el rol correspondiente.
- No incluye un motor antivirus. La auditoría de permisos/aplicaciones sigue pendiente.
- Los perfiles de juegos no cambian CPU/GPU ni garantizan FPS. Android limita el control sobre otras apps y procesos.
- Temperatura, batería, RAM, detección de juegos e historial de llamadas todavía pendientes.
- Multi-app abre ajustes del sistema; no reemplaza el Game Booster de HONOR ni fuerza ventanas flotantes en apps incompatibles.
- No mata procesos, no desactiva servicios de Android, no modifica ajustes ocultos y no ejecuta optimización permanente.

## Ahorro de RAM
El ahorro se consigue principalmente evitando que esta app permanezca trabajando en segundo plano. Android gestiona la RAM y puede cerrar procesos en caché. Cerrar apps a la fuerza o mantener un "limpiador" activo suele ser contraproducente.

## Compilación
Abrir en Android Studio con JDK 17 y SDK Android 35. Sin Gradle Wrapper incluido. Sin APK precompilado. Sin prueba de compilación en esta entrega.
